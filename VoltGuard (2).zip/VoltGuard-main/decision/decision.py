"""
Decision Engine
---------------
Given a physics-engine verdict (SAFE / WARNING / DANGER) for a command,
decides what happens to it:

    SAFE    -> ALLOW  (forwarded to the machine)
    WARNING -> ALLOW  (forwarded, but flagged for the operator)
    DANGER  -> BLOCK  (never reaches the machine)

Also builds the structured event used for the dashboard's event log.
"""

from datetime import datetime

ACTION_BY_STATUS = {
    "SAFE": "ALLOW",
    "WARNING": "ALLOW",
    "DANGER": "BLOCK",
}


def decide(command: dict, status: str) -> dict:
    action = ACTION_BY_STATUS.get(status, "BLOCK")

    return {
        "time": datetime.now().strftime("%H:%M:%S"),
        "packet_id": command.get("packet_id"),
        "rpm": command["rpm"],
        "pressure": command["pressure"],
        "flow_rate": command["flow_rate"],
        "status": status,
        "action": action,
    }


if __name__ == "__main__":
    sample = {"packet_id": 1234, "rpm": 6000, "pressure": 80, "flow_rate": 500}
    print(decide(sample, "WARNING"))
