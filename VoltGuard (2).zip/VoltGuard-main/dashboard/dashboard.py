"""
VoltGuard Dashboard
--------------------
Desktop operator dashboard (PyQt5). On every tick it pulls a simulated
packet from the capture module and pushes it through the full pipeline:

    capture.generate_packet -> parser.parse_packet
        -> physics.process_command -> decision.decide -> UI

Run with:  python main.py
      or:  python -m dashboard.dashboard
"""

import sys

from PyQt5.QtCore import Qt, QTimer, QDateTime
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QProgressBar, QListWidget, QListWidgetItem, QPushButton,
    QFrame, QGridLayout,
)

from capture.capture import generate_packet
from parser.parser import parse_packet, ParseError
from physics.physics import process_command
from physics.constants import MAX_RPM, MAX_PRESSURE, MAX_FLOW_RATE
from decision.decision import decide

STATUS_COLORS = {
    "SAFE": "#2ecc71",
    "WARNING": "#f1c40f",
    "DANGER": "#e74c3c",
    "REJECTED": "#e67e22",
}

# Headroom above the hard limits so a bar can visibly max out instead
# of just pinning at 100% the instant a limit is crossed.
RPM_DISPLAY_MAX = int(MAX_RPM * 2)
PRESSURE_DISPLAY_MAX = int(MAX_PRESSURE * 2.5)
FLOW_DISPLAY_MAX = int(MAX_FLOW_RATE * 1.5)

TICK_INTERVAL_MS = 1500


class VoltGuardDashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VoltGuard — Physics Firewall Dashboard")
        self.resize(760, 640)

        self.running = True
        self.allowed_count = 0
        self.blocked_count = 0

        self._build_ui()

        self.feed_timer = QTimer(self)
        self.feed_timer.timeout.connect(self.tick)
        self.feed_timer.start(TICK_INTERVAL_MS)

        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.update_clock()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(16, 16, 16, 16)
        root.setSpacing(12)

        # --- Header ------------------------------------------------
        header = QHBoxLayout()
        title = QLabel("⚡ VoltGuard")
        title.setFont(QFont("Segoe UI", 20, QFont.Bold))
        header.addWidget(title)
        header.addStretch()
        self.clock_label = QLabel()
        self.clock_label.setFont(QFont("Consolas", 14))
        header.addWidget(self.clock_label)
        root.addLayout(header)

        # --- Status banner -------------------------------------------
        self.status_label = QLabel("SAFE")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setFont(QFont("Segoe UI", 22, QFont.Bold))
        self.status_label.setMinimumHeight(60)
        root.addWidget(self.status_label)
        self._paint_status("SAFE")

        # --- Sensor readouts -------------------------------------------
        sensors_frame = QFrame()
        sensors_frame.setFrameShape(QFrame.StyledPanel)
        sensors_layout = QGridLayout(sensors_frame)

        self.rpm_bar, self.rpm_value = self._make_sensor_row(
            sensors_layout, 0, "RPM", RPM_DISPLAY_MAX)
        self.pressure_bar, self.pressure_value = self._make_sensor_row(
            sensors_layout, 1, "Pressure", PRESSURE_DISPLAY_MAX)
        self.flow_bar, self.flow_value = self._make_sensor_row(
            sensors_layout, 2, "Flow Rate", FLOW_DISPLAY_MAX)

        root.addWidget(sensors_frame)

        # --- Alarm panel -------------------------------------------------
        self.alarm_label = QLabel("No active alarms")
        self.alarm_label.setFont(QFont("Segoe UI", 11))
        self.alarm_label.setWordWrap(True)
        self.alarm_label.setStyleSheet(
            "padding: 8px; border-radius: 4px; "
            "background-color: #2c2c2c; color: #cccccc;"
        )
        root.addWidget(self.alarm_label)

        # --- Counters ------------------------------------------------------
        counters = QHBoxLayout()
        self.allowed_label = QLabel("Allowed: 0")
        self.blocked_label = QLabel("Blocked: 0")
        counters.addWidget(self.allowed_label)
        counters.addStretch()
        counters.addWidget(self.blocked_label)
        root.addLayout(counters)

        # --- Event log -------------------------------------------------
        log_title = QLabel("Event Log")
        log_title.setFont(QFont("Segoe UI", 11, QFont.Bold))
        root.addWidget(log_title)

        self.event_log = QListWidget()
        self.event_log.setAlternatingRowColors(True)
        root.addWidget(self.event_log, stretch=1)

        # --- Controls ----------------------------------------------------
        controls = QHBoxLayout()
        self.toggle_btn = QPushButton("Pause Feed")
        self.toggle_btn.clicked.connect(self.toggle_feed)
        controls.addWidget(self.toggle_btn)
        controls.addStretch()
        root.addLayout(controls)

    def _make_sensor_row(self, layout, row, label_text, max_value):
        label = QLabel(label_text)
        label.setFont(QFont("Segoe UI", 11, QFont.Bold))
        layout.addWidget(label, row, 0)

        bar = QProgressBar()
        bar.setRange(0, max_value)
        bar.setTextVisible(False)
        layout.addWidget(bar, row, 1)

        value_label = QLabel("--")
        value_label.setFixedWidth(100)
        value_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        layout.addWidget(value_label, row, 2)

        return bar, value_label

    # ------------------------------------------------------------------
    # Behaviour
    # ------------------------------------------------------------------
    def update_clock(self):
        now = QDateTime.currentDateTime().toString("yyyy-MM-dd  HH:mm:ss")
        self.clock_label.setText(now)

    def toggle_feed(self):
        self.running = not self.running
        self.toggle_btn.setText("Resume Feed" if not self.running else "Pause Feed")

    def tick(self):
        if not self.running:
            return

        raw_packet = generate_packet()

        try:
            command = parse_packet(raw_packet)
        except ParseError as exc:
            self._log_rejected(raw_packet, exc)
            return

        try:
            status = process_command(command)
        except ValueError:
            # validator caught a negative/malformed value
            status = "DANGER"

        event = decide(command, status)
        self._apply_event(event)

    def _apply_event(self, event):
        self._update_sensors(event)
        self._paint_status(event["status"])
        self._update_alarm(event)
        self._update_counters(event)
        self._log_event(event)

    def _update_sensors(self, event):
        rpm, pressure, flow = event["rpm"], event["pressure"], event["flow_rate"]
        self.rpm_bar.setValue(min(int(rpm), RPM_DISPLAY_MAX))
        self.rpm_value.setText(f"{rpm:.0f} rpm")

        self.pressure_bar.setValue(min(int(pressure), PRESSURE_DISPLAY_MAX))
        self.pressure_value.setText(f"{pressure:.1f} psi")

        self.flow_bar.setValue(min(int(flow), FLOW_DISPLAY_MAX))
        self.flow_value.setText(f"{flow:.1f} L/min")

        color = STATUS_COLORS[event["status"]]
        for bar in (self.rpm_bar, self.pressure_bar, self.flow_bar):
            bar.setStyleSheet(f"QProgressBar::chunk {{ background-color: {color}; }}")

    def _paint_status(self, status):
        color = STATUS_COLORS.get(status, "#7f8c8d")
        self.status_label.setText(status)
        self.status_label.setStyleSheet(
            f"background-color: {color}; color: #1b1b1b; border-radius: 6px;"
        )

    def _update_alarm(self, event):
        pid, rpm, pressure, flow = (
            event["packet_id"], event["rpm"], event["pressure"], event["flow_rate"],
        )
        if event["status"] == "DANGER":
            self.alarm_label.setText(
                f"🔴 BLOCKED — packet #{pid} exceeded safe limits "
                f"(rpm={rpm:.0f}, pressure={pressure:.1f}, flow={flow:.1f})"
            )
            self.alarm_label.setStyleSheet(
                "padding: 8px; border-radius: 4px; "
                "background-color: #4a1414; color: #ff8888;"
            )
        elif event["status"] == "WARNING":
            self.alarm_label.setText(
                f"🟡 Packet #{pid} forwarded with warning "
                f"(rpm={rpm:.0f}, pressure={pressure:.1f}, flow={flow:.1f})"
            )
            self.alarm_label.setStyleSheet(
                "padding: 8px; border-radius: 4px; "
                "background-color: #4a3d14; color: #ffe08a;"
            )
        else:
            self.alarm_label.setText("No active alarms")
            self.alarm_label.setStyleSheet(
                "padding: 8px; border-radius: 4px; "
                "background-color: #2c2c2c; color: #cccccc;"
            )

    def _update_counters(self, event):
        if event["action"] == "BLOCK":
            self.blocked_count += 1
        else:
            self.allowed_count += 1
        self.allowed_label.setText(f"Allowed: {self.allowed_count}")
        self.blocked_label.setText(f"Blocked: {self.blocked_count}")

    def _log_event(self, event):
        text = (
            f"[{event['time']}] #{event['packet_id']}  "
            f"rpm={event['rpm']:.0f} pressure={event['pressure']:.1f} "
            f"flow={event['flow_rate']:.1f}  → {event['status']} ({event['action']})"
        )
        self._insert_log_row(text, event["status"])

    def _log_rejected(self, raw_packet, exc):
        text = f"[{QDateTime.currentDateTime().toString('HH:mm:ss')}] REJECTED packet — {exc}"
        self._insert_log_row(text, "REJECTED")

    def _insert_log_row(self, text, status):
        item = QListWidgetItem(text)
        item.setForeground(QColor(STATUS_COLORS.get(status, "#e67e22")))
        self.event_log.insertItem(0, item)
        while self.event_log.count() > 200:
            self.event_log.takeItem(self.event_log.count() - 1)


def run():
    app = QApplication(sys.argv)
    window = VoltGuardDashboard()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    run()
