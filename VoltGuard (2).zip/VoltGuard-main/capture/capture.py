"""
Packet Capture (simulated)
---------------------------
Stands in for the real Modbus/DNP3 packet interceptor. Produces a raw
"packet" carrying live sensor readings, the same shape a decoded
industrial command would have. Swap this module out for a real
Scapy/pyModbus sniffer without touching anything downstream.
"""

import random
from datetime import datetime


def generate_packet():
    packet = {
        "packet_id": random.randint(1000, 9999),
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "rpm": random.randint(1000, 9000),
        "pressure": round(random.uniform(10, 250), 1),
        "flow_rate": round(random.uniform(100, 1400), 1),
        "temperature": random.randint(20, 150),
    }
    return packet


if __name__ == "__main__":
    print(generate_packet())
