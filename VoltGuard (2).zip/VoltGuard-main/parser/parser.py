"""
Packet Parser
-------------
Turns a raw captured packet (from capture.generate_packet, or in a real
deployment, a decoded Modbus/DNP3 frame) into the clean "command" dict
the physics engine expects:

    {"rpm": float, "pressure": float, "flow_rate": float, ...}

Any packet missing a required field, or carrying a non-numeric value,
is rejected with a ParseError so a malformed/malicious packet never
reaches the physics engine.
"""

REQUIRED_FIELDS = ("rpm", "pressure", "flow_rate")


class ParseError(Exception):
    """Raised when a raw packet cannot be turned into a valid command."""


def parse_packet(raw_packet: dict) -> dict:
    if not isinstance(raw_packet, dict):
        raise ParseError("Packet is not a dict")

    command = {}
    for field in REQUIRED_FIELDS:
        if field not in raw_packet:
            raise ParseError(f"Packet missing required field: {field}")
        try:
            command[field] = float(raw_packet[field])
        except (TypeError, ValueError):
            raise ParseError(f"Packet field '{field}' is not numeric")

    # Carry a few extra fields through for display/logging, if present.
    command["packet_id"] = raw_packet.get("packet_id")
    command["timestamp"] = raw_packet.get("timestamp")
    command["temperature"] = raw_packet.get("temperature")

    return command


if __name__ == "__main__":
    from capture.capture import generate_packet
    print(parse_packet(generate_packet()))
